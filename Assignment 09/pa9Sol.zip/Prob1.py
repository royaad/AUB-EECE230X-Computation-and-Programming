# -*- coding: utf-8 -*-
"""
Created on Fri Apr  5 10:25:10 2019

@author: louay
"""


def equalElementsSlow(M):# O(m^2*n^2)
    """ assumes  M is an m by n matrix """
    m = len(M)
    n = len(M[0])
    for i1 in range(m):
        for j1 in range(n): 
            for i2 in range(i1,m):
                for j2 in range(n):        
                     if (i1,j1)!=(i2,j2) and M[i1][j1] == M[i2][j2]: 
                         return ((i1,j1),(i2,j2))
    return ((-1,-1),(-1,-1))
           

def equalElementsFast(M):# O(m*n) expected time using a dict 
    """ assumes  M is an m by n matrix """
    m = len(M)
    n = len(M[0])
    D = {}
    for i in range(m):
        for j in range(n): 
            if M[i][j] not in D:
                D[M[i][j]] = (i,j)
            else: 
                return (D[M[i][j]],(i,j))
    return ((-1,-1),(-1,-1))
        
import numpy as np
M1 = [[1,2],[3,4]]  
M2 = [[1,2],[3,1]]
M3 = [[1,3,0,5],[2,5,2,-1],[5,6,-2,6]]
M4 = [[1,3,0,5],[20,50,2,-1],[51,61,-2,16]]
for M in (M1,M2,M3,M4):
    print(np.matrix(M))
    print(equalElementsSlow(M))
    print(equalElementsFast(M),"\n")


           

           