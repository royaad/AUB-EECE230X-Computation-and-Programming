# -*- coding: utf-8 -*-
"""
Created on Sun Oct 21 14:13:01 2018

@author: louay
"""


################################################        
def parenthesesAndBracesChecker(s):  
    # Use a list a stack to match parentheses and brackets
    S = []
    for c in s: 
        #If we have an open  parenthesis or bracket, we add it to the Stack S
        if c == '(' or c == '[' or c == '{':
            S.append(c)
        #If it is a closed parenthesis or bracket, we need to match it with  its open counterpart 
        #To do so, we check the last element added to the stack
        #If  it doen’t  match, we return false
        elif c==')':
            if len(S)==0 or S.pop()!='(': return False   
        elif c==']':
            if len(S)==0 or S.pop()!='[': return False        
    #If we reach the  end of the loop, then there was no mismatch
    #Finally, we check if the  stack is empty as  some open parentheses or brackets might still be unmatched
    #If the stack is empty,  we return True          
    if len(S)==0: 
        return True 
    else:
        return False
    
            
    
for s in  ("a(aa)aa", "aa(b(cd))e[ab]", "([aa(b)c[[aaaaa]]r(d)])", "a([b)]",  "((aab)d", "((", "ef)]"): 
            print("Checking parenthesesAndBraces in \""+s+"\" :",parenthesesAndBracesChecker(s) )
