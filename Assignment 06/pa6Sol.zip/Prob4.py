# -*- coding: utf-8 -*-
"""
Created on Wed Mar 17 16:23:38 2021

@author: louay
"""
        
def  merge(L, R): # Time: O(len(L)+len(R))
    """ Assumes L (left) and R (right) are lists of numbers sorted in non-decreasing order
        Returns a list C consisting L and R merged in non-decreasing order """
    C = []     ## initialize C to the empty list
    m = len(L)
    n = len(R)
    i = 0 # counter to traverse L 
    j = 0 # counter to traverse R
    while i!=m and j !=n: 
        if L[i]<R[j]: 
            C.append(L[i])
            i+=1
        else: 
            C.append(R[j])
            j+=1
    while i!=m: # if R is done, append remaining elements of L to C 
        C.append(L[i])
        i+=1       
    while j!=n: # if L is done, append remaining elements of R to C 
        C.append(R[j])
        j+=1      
    return C

print(merge([1,3,5,7,9],[2,4,6,8,10]))
print(merge([1,5,7],[2,3,5,8,9,9]))
print(merge([1,5,7],[20,30,50,80,90,90]))
print(merge([10,50,70],[2,3,5,8,9,9]))
print(merge([1,5,7],[]))
print(merge([],[2,3,5,8,9,9]))
print(merge([1,2,3],[1,2,3]))



    