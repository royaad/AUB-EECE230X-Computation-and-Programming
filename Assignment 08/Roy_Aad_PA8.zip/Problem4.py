def  merge(L, R): # Time: O(len(L)+len(R))
    """ Assumes L (left) and R (right) are lists of numbers sorted in non-decreasing order
        Returns a list C consisting L and R merged in non-decreasing order """
    C = []     ## initialize C to the empty list
    m = len(L)
    n = len(R)
    i = 0 # counter to traverse L 
    j = 0 # counter to traverse R
    while i!=m and j !=n: 
        if L[i]<R[j]: 
            C.append(L[i])
            i+=1
        else: 
            C.append(R[j])
            j+=1
    while i!=m: # if R is done, append remaining elements of L to C 
        C.append(L[i])
        i+=1       
    while j!=n: # if L is done, append remaining elements of R to C 
        C.append(R[j])
        j+=1      
    return C

def ternaryMergeSort(A, low, high): 
    # Base case: if low==high, in which case nothing to be done: 
    #  as a size-1    list is already sorted
    if low<high: 
        third = low + (high - low)//3
        twoThird = low + 2*(high - low)//3
        ternaryMergeSort(A, low, third)         # first recursive call 
        ternaryMergeSort(A, third+1, twoThird)  # second recursive call
        ternaryMergeSort(A, twoThird+1, high)   # third recursive call
        temp = merge(A[low:third+1], A[third+1:twoThird+1])
        A[low:high+1] = merge(temp, A[twoThird+1:high+1])
        # Recall that A[a:b+1] gives  A[a ... b]

A = [5,6,1,3,2,1,7,9,5,15,100, 2,17,56]
ternaryMergeSort(A, 0, len(A)-1)
print(A)
A = [2,1]
ternaryMergeSort(A, 0, len(A)-1)
print(A)
A = []
ternaryMergeSort(A, 0, len(A)-1)
print(A)
A= [1]
ternaryMergeSort(A, 0, len(A)-1)
print(A)
A = [20-i for i in range(20)] #, i.e., [20,19, ..., 1]
ternaryMergeSort(A, 0, len(A)-1)
print(A)

''' the running time of Ternary Merge Sort.
T(n) = 3*T(n/3) + c*n       if n = 3, 9, 27...
T(n) = c0                   if n = 1

according to Master Theorem
a = 3
b = 3
k = 1
logb(a) = 1 = k
then T(n) = Θ(n*log(n))
'''